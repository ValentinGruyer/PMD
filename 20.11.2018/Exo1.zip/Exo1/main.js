//Requête asynchrone sur un fichier HTML
fetch("content/accueil.html")
//1er callback : analyse et traitement du fetch
.then(responseRaw => {
    console.log(responseRaw);
})
.catch(error =>{
    console.error(error);
})