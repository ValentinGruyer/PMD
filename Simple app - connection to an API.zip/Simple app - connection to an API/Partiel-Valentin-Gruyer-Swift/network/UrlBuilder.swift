//
//  UrlBuilder.swift
//  Partiel-Valentin-Gruyer-Swift
//
//  Created by valentin gruyer on 19/04/2019.
//  Copyright © 2019 valentin gruyer. All rights reserved.
//

import Foundation
class UrlBuilder {
    
    private static let baseUrl: String = {
        let isProduction = true
        
        if isProduction {
            return "https://comicvine.gamespot.com"
        } else {
            return "https://comicvine.gamespot.com"
        }
    }()
    
    static let urlEpisode: String = {
        let apiKey = ""//Enter your API key here
        return "\(baseUrl)/api/movies/?api_key=\(apiKey)&format=json"
    }()
}
