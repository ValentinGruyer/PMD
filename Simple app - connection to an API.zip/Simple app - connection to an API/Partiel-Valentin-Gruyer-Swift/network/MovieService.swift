//
//  MovieService.swift
//  Partiel-Valentin-Gruyer-Swift
//
//  Created by valentin gruyer on 19/04/2019.
//  Copyright © 2019 valentin gruyer. All rights reserved.
//

import Foundation
import Alamofire

class MovieService {
    
    
    typealias SuccessMovies = (_ movie: [Movie]) -> Void
    typealias Failure = (_ error: Error) -> Void
    
    static func retrieveMovies(success: @escaping SuccessMovies, failure: @escaping  Failure) {
        let url = UrlBuilder.urlEpisode
        
        
        let jsonDecoder = JSONDecoder()
        jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
        AF.request(url)
            .responseDecodable(queue: nil, decoder: jsonDecoder) { (response: DataResponse<MovieResult>) in

                switch response.result {
                case .success(let value):
                    let results = value.results
                    
                    success(results)
                    //print(results)
                    
                case .failure(let error):
                    print("error: \(error)")
                    
                    failure(error)
                }
        }
    }
}
