//
//  MovieDetailViewController.swift
//  Partiel-Valentin-Gruyer-Swift
//
//  Created by valentin gruyer on 19/04/2019.
//  Copyright © 2019 valentin gruyer. All rights reserved.
//

import UIKit
import Kingfisher

class MovieDetailViewController: UIViewController {

   
    @IBOutlet weak var descDetail: UIWebView!
    @IBOutlet weak var imageDetail: UIImageView!
    
    var currentMovie:Movie!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title=currentMovie.name
        descDetail.loadHTMLString(currentMovie.description ?? "", baseURL: nil)
        
        // Do any additional setup after loading the view.
        self.imageDetail.kf.setImage(with: URL(string:currentMovie.image["screenUrl"]!))
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
