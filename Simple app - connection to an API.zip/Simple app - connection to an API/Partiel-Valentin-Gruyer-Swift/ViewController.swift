//
//  HomeViewController.swift
//  Partiel-Valentin-Gruyer-Swift
//
//  Created by valentin gruyer on 19/04/2019.
//  Copyright © 2019 valentin gruyer. All rights reserved.
//
import UIKit

class ViewController: UIViewController {
    lazy var movies = [Movie]() //Tab avec les éléments filtrés
    lazy var allMovies = [Movie]()//Tab avec tous les éléments
    
    let detailMovieIdentifier = "movieDetail"

    @IBOutlet weak var MovieTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        MovieService.retrieveMovies(success: { (movies) in
            // Stockage des épisodes dans mon tableau global (celui qui est utilisé par le DataSource)
            self.movies.removeAll()
            self.movies.append(contentsOf: movies)
            //On stocke aussi tous les épisodes dans un autre tableau qu'on ne filtrera pas
            self.allMovies.removeAll()
            self.allMovies.append(contentsOf: movies)
            // On ordonne au tableView de se recharger
            
            self.MovieTableView.reloadData()
            
        }) { (error) in
            // Afficher une erreur
        }
        
    }
    //Pour le 2ème écran
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        // Comment savoir où l'on va ? Vers quel écran ?
        // grâce à l'identifiant du segue
        
        if segue.identifier == detailMovieIdentifier {
            let detailViewController = segue.destination as! MovieDetailViewController
            
            // sender = élément graphique qui a déclenché le segue
            
            // cell = sender sous forme de EpisodeTableViewCell
            // => accès direct à la cellule
            if let cell = sender as? MovieTableViewCell {
                let movie = cell.movie
                
                detailViewController.currentMovie = movie
            }
        }
    }

}


// on rajoute les méthodes à notre ViewController
// pour qu'il puisse assurer le rôle de Datasource auprès
// de la TableView (nombre cellules + les cellules)
extension ViewController: UITableViewDataSource {
    
    // méthode appelée par la TableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    // méthode appelée par la TableView
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieTableViewCell.identifier, for: indexPath) as! MovieTableViewCell
        // as! EpisodeTableViewCell = cast de UITableViewCell en EpisodeTableViewCell (fr : transtypage)
        
        cell.movie = movies[indexPath.row]
        
        return cell
    }
    
    
}
extension ViewController: UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty{
            self.movies = allMovies
        }else{
            self.movies = allMovies.filter({ (episode) -> Bool in
                //true = conserve l'épisode (fera donc parti du tableau filtré)
                //flase = ne conserve pas l'épisode
                return episode.name.lowercased().contains(searchText.lowercased())
            })
            //On rafraichi la tableview
            self.MovieTableView.reloadData()
        }
    }
}
