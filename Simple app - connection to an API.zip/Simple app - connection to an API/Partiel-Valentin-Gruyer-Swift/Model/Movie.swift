//
//  Movie.swift
//  Partiel-Valentin-Gruyer-Swift
//
//  Created by valentin gruyer on 19/04/2019.
//  Copyright © 2019 valentin gruyer. All rights reserved.
//

import Foundation
struct Movie : Decodable {
    let name : String
    let description : String!
    let image : [String:String]
}
