//
//  MovieTableViewCell.swift
//  Partiel-Valentin-Gruyer-Swift
//
//  Created by valentin gruyer on 19/04/2019.
//  Copyright © 2019 valentin gruyer. All rights reserved.
//

import UIKit
import Kingfisher
class MovieTableViewCell: UITableViewCell {

    static let identifier = "movieCellIdentifier"
    
    @IBOutlet weak var movieLabel: UILabel!
    @IBOutlet weak var movieImage: UIImageView!
    var movie: Movie! {
        didSet {
            // Refresh UI
            self.movieLabel.text = movie.name
            self.movieImage.kf.setImage(with: URL(string: movie.image["thumbUrl"]!))
            
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    
}
